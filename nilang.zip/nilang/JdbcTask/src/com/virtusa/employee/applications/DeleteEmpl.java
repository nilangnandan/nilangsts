package com.virtusa.employee.applications;

import com.virtusa.employee.employee.dao.EmployeeDao;

public class DeleteEmpl {

	public static void main(String[] args) {
		EmployeeDao dao = new EmployeeDao();
		int rows= dao.deleteEmpl(181);
		if(rows>0)
			System.out.println("deleted");
		else
			System.out.println("not deleted");

	}

}
