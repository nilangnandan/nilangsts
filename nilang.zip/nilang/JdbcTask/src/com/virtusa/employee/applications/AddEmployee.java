package com.virtusa.employee.applications;

import com.virtusa.employee.beans.Employee;
import com.virtusa.employee.employee.dao.EmployeeDao;

public class AddEmployee {

	public static void main(String[] args) {
		Employee emp = new Employee(181,"virtusa", "trainer", 20000, "04-09-2018");
		EmployeeDao dao = new EmployeeDao();
		int rows = dao.addEmployee(emp);
		if(rows>0)
			System.out.println("inserted");
		else
			System.out.println("not inserted");
	}

}
