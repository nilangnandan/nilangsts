package com.virtusa.employee.applications;

import java.util.List;

import com.virtusa.employee.beans.Employee;
import com.virtusa.employee.employee.dao.EmployeeDao;

public class GetEmpls {

	public static void main(String[] args) {
		EmployeeDao dao = new EmployeeDao();
		List<Employee> empls = dao.getAllEmpls();
		for( Employee e :empls)
			System.out.println(e.getEmpcode()+" "+e.getEmpname());
		Employee emp = dao.getEmpl(121);
		if(emp == null)
			System.out.println("employee not exist");
		else 
			System.out.println(emp.getEmpcode()+" "+emp.getEmpname());
	}

}
