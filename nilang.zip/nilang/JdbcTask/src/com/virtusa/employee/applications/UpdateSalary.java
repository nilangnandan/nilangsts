package com.virtusa.employee.applications;

import com.virtusa.employee.employee.dao.EmployeeDao;

public class UpdateSalary {

	public static void main(String[] args) {
		EmployeeDao dao = new EmployeeDao();
		int rows = dao.updateEmpl(121);
		if(rows>0)
			System.out.println("Updated");
		else
			System.out.println("not updated");
	}

}
