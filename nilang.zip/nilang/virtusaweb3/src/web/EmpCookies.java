package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmpCookies
 */
@WebServlet("/EmpCookies")
public class EmpCookies extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String userid = request.getParameter("user");
		String mail= request.getParameter("email");
		String mobile=  request.getParameter("mobile");
		Cookie ck1= new Cookie(name, userid);
		Cookie ck2= new Cookie(name, mobile);
		Cookie ck3= new Cookie(name, mail);
		ck1.setMaxAge(24*60*60);
		ck2.setMaxAge(24*60*60);
		ck3.setMaxAge(24*60*60);
		response.addCookie(ck1);
		response.addCookie(ck2);
		response.addCookie(ck3);
		out.println("Cookie created. <a href='EmployeeDetails.html'> click here to add more cookie</a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
