package web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeDetails
 */
@WebServlet("/EmployeeDetails")
public class EmployeeDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String firstname= request.getParameter("firstname");
		String lastname= request.getParameter("lastname");
		String email= request.getParameter("email");
		long mobile = Long.parseLong(request.getParameter("mobile"));
		String address= request.getParameter("address");
		String skills[]= request.getParameterValues("skills");
		String doj= request.getParameter("doj");
		
		out.println("Name "+ firstname);
		out.println(lastname+" <br>");
		out.println("Email "+email +" <br>");
		out.println("Mobile No. "+mobile +" <br>");
		out.println("Address "+address+ " <br>");
		out.println("Skills ");
		for(String s:skills)
			out.println(s);
		out.println("<br> "+"Date of Joining "+doj);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
		
	}
}
