package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = null;
		HttpSession session= request.getSession();
		String user = request.getParameter("username");
		String pass = request.getParameter("pass");
		if(user.equals("admin") && pass.equals("admin")) {
				session.setAttribute("admin", true);
				rd = request.getRequestDispatcher("Admin");
		}
		else if(user.equals("virtusa")) {
			if(pass.equals("virtusa")) {
				session.setAttribute("virtusa", true);
				rd = request.getRequestDispatcher("User");
			}
			
		}
		if(rd==null) {
			out.println("bug3");
			out.println("<font color='red' >Invalid User</font>");
			rd = request.getRequestDispatcher("Login.html");
			rd.forward(request, response);
		}
		rd.forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
