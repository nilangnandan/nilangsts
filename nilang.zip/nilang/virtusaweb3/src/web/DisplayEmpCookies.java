package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayEmpCookies
 */
@WebServlet("/DisplayEmpCookies")
public class DisplayEmpCookies extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Cookie[] cks= request.getCookies();
		out.println("<table border=\"2\" >\r\n" + 
				"	  <tr >\r\n" + 
				"		<th rowspan= \"2\"><font >Name</font></th>\r\n" + 
				"		<th colspan= \"3\" ><font > Cookies</font></th>\r\n" + 
				"	  </tr>\r\n"+
				" 		<tr>\r\n"+
				"		<th> <font >ID</font></th> <th> Mobile</th><th> Mail Id</th>\r\n"+
				" 	  	</tr>\r\n");
		int count=0;
		for(Cookie c :cks) {
			if(count%4==0) {
				out.println("<tr> ");
				out.println("<td> "+c.getName()+"</td>");
			}
			out.println("<td>"+ c.getValue()+"</td>");
			
			count++;
			if(count%4==3) {
				out.println("</tr> ");
				count++;
			}
				
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
