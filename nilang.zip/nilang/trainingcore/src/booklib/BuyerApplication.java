package booklib;

import java.util.Scanner;

public class BuyerApplication {

	public static void message() {
		System.out.println("Enter the appropriate alphabet");
		System.out.println("a - Search By Author ");
		System.out.println("p - Search by Publisher ");
		System.out.println("t - Search By Title ");
		System.out.println("x - Exit ");
		
	}
	public static void main(String[] args) {
		BookOperations oprs = new BookOperations();
		message();
		Scanner entry = new Scanner(System.in);
		String input= entry.next();
		while(!input.equals("x")) {
			if(input.equals("a")) {
				oprs.searchByAuthor();
				message();
				input = entry.next();
			}
			else if(input.equals("p")) {
				oprs.searchByPublisher();
				message();
				input = entry.next();
			}
			else if(input.equals("t")) {
				oprs.searchByTitle();
				message();
				input = entry.next();
			}
			
			else {
				System.out.println("Please enter a valid response");			
				message();
				input= entry.next();
			}
		}
		entry.close();
		
		System.out.println("Thank you; Visit again");
	}

}
