package booklib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BookOperations {
	private ArrayList<Book> bookList = new ArrayList<>();
	private int idNo =1234;
	
	public BookOperations() {
		Book book1 = new Book(1230,"The_Hunger_Games", "3rd","Suzanne_Collins","abc",1990, "Hunger wala hai", 10, 120);
		Book book2 = new Book(1231,"Harry_Potter_and_the_Order_of_the_Phoenix", "3rd","J.K.Rollings","abc",1990, "Potter Bhai", 10, 120);
		Book book3 = new Book(1232,"To_Kill_a_Mockingbird", "3rd","Harper_Lee","abc",1990, "Hunger wala hai", 10, 120);
		Book book4 = new Book(1233,"Pride_and_Prejudice", "3rd","Jane_Austen","abc",1990, "Hunger wala hai", 10, 120);
		bookList.add(book1);
		bookList.add(book2);
		bookList.add(book3);
		bookList.add(book4);
	}

	//For adding new book into list
	public void newBook(){
		System.out.println("Enter the book details");
		Scanner sc = new Scanner(System.in);
		//Book Id will be auto Generated
		System.out.println("Enter Book Title :");
		String titlenew = sc.next()	;
		System.out.println("Enter Book edition :");
		String editionNew = sc.next();
		System.out.println("Enter Book's Author :");
		String authorNew = sc.next();
		System.out.println("Enter Book's publisher :");
		String publisherNew = sc.next();
		System.out.println("Enter Book's published year :");
		int publishedYearNew = sc.nextInt();
		System.out.println("Enter Book description :");
		String descriptionNew = sc.next();
		System.out.println("Enter Book's quantity :");
		int quantityNew = sc.nextInt();
		System.out.println("Enter Book's cost :");
		double costNew = sc.nextDouble();
		Book bookNew = new Book(idNo, titlenew, editionNew, authorNew, publisherNew,publishedYearNew, descriptionNew, quantityNew,costNew);
		System.out.println("Your book is sucessfully added and book id is : "+ idNo);
		idNo++;
		bookList.add(bookNew);
		sc.close();
	}
	
	// To update stock of book
	public void updateStock() {
		int flag=0;
		System.out.println("Enter Book's Id to be updated :");
		Scanner sc = new Scanner(System.in);
		int bookIdUpdate = sc.nextInt();
		System.out.println("Enter book quantity to be added :");
		int quantityUpdate = sc.nextInt();
		try {
			for(Book bookUpdate : bookList) {
				if(bookIdUpdate == bookUpdate.getBookId()) {
					bookUpdate.setQuantity(bookUpdate.getQuantity()+quantityUpdate);
					flag=1;
					System.out.println("Your stock has been sucessfully updated.");
					break;
				}
			}
			sc.close();
			if (flag ==0)
				throw new BookNotFound();
		}
		catch(BookNotFound e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}
	
	//Delete book which delete whole row of book including all the quantity
	
	public void deleteBook() {
		int flag=0;
		System.out.println("Enter Book's Id to delete :");
		Scanner sc = new Scanner(System.in);
		int bookIdDelete = sc.nextInt();
		try {
			for(Book bookDelete : bookList) {
				if(bookIdDelete == bookDelete.getBookId()) {
					bookList.remove(bookDelete);
					flag=1;
					System.out.println("Your stock has been sucessfully updated.");
					break;
				}
			}
			sc.close();
			if (flag ==0)
				throw new BookNotFound();
		}
		catch(BookNotFound e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}
	
	//Search by Author
	public void searchByAuthor() {
		//ArrayList<Book> sortedList = new ArrayList<>();
		System.out.println("Enter Author name :");
		Scanner sc = new Scanner(System.in);
		String author = sc.next();
		Collections.sort(bookList, new SortByTitle());
		int flag=0;
		for(Book searchBook : bookList) {
			if(searchBook.getAuthor().equals(author)) {
				System.out.println(searchBook.getTitle());
				flag=1;
			}
		}
		if(flag==0)
			System.out.println("No book is available of this author");
		sc.close();
	}
	
	public void searchByTitle() {
		//ArrayList<Book> sortedList = new ArrayList<>();
		System.out.println("Enter Book Title :");
		Scanner sc = new Scanner(System.in);
		String author = sc.next();
		//Collections.sort(bookList, new SortByTitle());
		int flag=0;
		for(Book searchBook : bookList) {
			if(searchBook.getAuthor().equals(author)) {
				System.out.println(searchBook.getTitle());
				flag=1;
			}
		}
		if(flag==0)
			System.out.println("No book is available by this title");	
		sc.close();
	}
	
	public void searchByPublisher() {
		//ArrayList<Book> sortedList = new ArrayList<>();
		System.out.println("Enter Book's Publisher :");
		Scanner sc = new Scanner(System.in);
		String author = sc.next();
		int flag=0;
		Collections.sort(bookList, new SortByTitle()); //bookList is name of arraylist
		for(Book searchBook : bookList) {
			if(searchBook.getAuthor().equals(author)) {
				System.out.println(searchBook.getTitle());
				flag=1;
			}
		}
		if(flag==0)
			System.out.println("No book is available by this publisher");	
		sc.close();
	}
}
