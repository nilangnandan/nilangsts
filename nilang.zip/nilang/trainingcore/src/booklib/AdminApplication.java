package booklib;

import java.util.Scanner;

public class AdminApplication {
	
	public static void message() {
		System.out.println("Enter the appropriate alphabet");
		System.out.println("a - Add new book ");
		System.out.println("u - Update Stock ");
		System.out.println("d - Delete book ");
		System.out.println("x - Exit ");
		
	}
	public static void main(String[] args) {
		BookOperations oprs = new BookOperations();
		message();
		Scanner entry = new Scanner(System.in);
		String input= entry.next();
		while(!input.equals("x")) {
			if(input.equals("d")) {
				oprs.deleteBook();
				message();
				input = entry.next();
			}
			else if(input.equals("u")) {
				oprs.updateStock();
				message();
				input = entry.next();
			}
			else if(input.equals("a")) {
				oprs.newBook();
				message();
				input = entry.next();
			}
			
			else {
				System.out.println("Please enter a valid response");			
				message();
				input= entry.next();
			}
			entry.close();
		}
	}

}
