package utils;


import java.util.TreeSet;

public class usingTreeSet {

	public static void main(String[] args) {
		TreeSet data = new TreeSet<>();
		data.add("xyz");
		data.add("virtusa");
		data.add("Virt");
		data.add("567");
		data.add("1567");
		data.add("#567");
		System.out.println(data);
	}

}
