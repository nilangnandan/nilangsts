package utils;

import java.util.ArrayList;
import java.util.Iterator;

public class testArrayList {

	public static void main(String[] args) {
		ArrayList items = new ArrayList();
		items.add(567);
		items.add("virtusa");
		items.add(4678);
		items.add("hyd");
		items.add(null);
		System.out.println(items);
		items.add(567);
		System.out.println(items+" "+items.size());
		items.remove("hyd"); // In string case it automatically find that its not index
		System.out.println(items+" "+items.size());
		items.remove(3); // remove value by index
		System.out.println(items+" "+items.size());
		items.remove(new Integer(567)); // we can put value using wrapper class // remove 1st value only
		System.out.println(items+" "+items.size());
		System.out.println("Now iterator will start");
		Iterator itr = items.listIterator();
		while (itr.hasNext()) {
			Object obj = itr.next();
			if(obj instanceof String)
				System.out.println(obj);
		}
	}

}
