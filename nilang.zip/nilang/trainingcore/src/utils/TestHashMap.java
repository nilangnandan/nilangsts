package utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class TestHashMap {

	public static void main(String[] args) {
		//HashMap<String, Integer> data = new HashMap<>();
		TreeMap<String, Integer> data = new TreeMap<>();
		data.put("Virtusa", 1234);
		data.put("fos", 7467);
		data.put("java", 73174);
		data.put("ccufc", 4634);
		data.put("virtusa", 1234);
		System.out.println(data);
		System.out.println(data.get("java"));
		Set set = data.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
	}

}
