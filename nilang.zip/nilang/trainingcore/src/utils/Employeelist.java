package utils;

import java.util.ArrayList;
import java.util.Collections;

public class Employeelist {

	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		Employee emp1= new Employee(101, "Virtusa");
		Employee emp2= new Employee(102, "Hyd");
		Employee emp3= new Employee(103, "Duhyhk");
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		Collections.sort(empList, new SortByName());//sort is static method
		for(Employee emp : empList)
			System.out.println(emp.getCode()+" "+emp.getName());
		
	}

}
