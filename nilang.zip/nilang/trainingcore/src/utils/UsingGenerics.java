package utils;

import java.util.ArrayList;

public class UsingGenerics {

	public static void main(String[] args) {
		ArrayList<String> items = new ArrayList<>();
		items.add("hyd");
		items.add("Virtusa");
		items.add("engg.");
		System.out.println(items);
		for(String s : items) {
			System.out.println(s);
			for(int i=0; i< s.length();i++)
				System.out.println(s.charAt(i));
		}
	}

}
