package utils;

import java.util.HashSet;

public class UsingHashSet {

	public static void main(String[] args) {
		HashSet data = new HashSet<>();
		data.add("xyz");
		data.add("virtusa");
		data.add("Virt");
		data.add(567);
		System.out.println(data);
	}

}
