package trainingcore;

public class Bus implements Vehicle{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle volvo = new Bus();
		volvo.engine();
		volvo.wheels();
	}

	@Override
	public void engine() {
		// TODO Auto-generated method stub
		System.out.println("It has 1 engine");
	}

	@Override
	public void wheels() {
		// TODO Auto-generated method stub
		System.out.println("It has 10 wheels");
	}

}
