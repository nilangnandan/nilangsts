package trainingcore;

public class PlacementCell extends StudentExamDetails{

	protected int drives;
	protected String status;
	
	
	
	public PlacementCell(int drives, String status) {
		this.drives = drives;
		this.status = status;
	}



	public PlacementCell() {
		super();
		// TODO Auto-generated constructor stub
	}



	public PlacementCell(int sub1, int sub2, int sub3) {
		super(sub1, sub2, sub3);
		// TODO Auto-generated constructor stub
	}



	public PlacementCell(int regno, String studentName, String group) {
		super(regno, studentName, group);
		// TODO Auto-generated constructor stub
	}
	
	public void info(int sub1, int sub2, int sub3, int drives, String status) {
		PlacementCell std=  new PlacementCell(sub1, sub2, sub3);
		std.result(sub1, sub2, sub3);
		System.out.println(drives + " "+ status);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PlacementCell std=  new PlacementCell(8,"Selected");
		std.info(98, 42, 62, 7, "Selected");
		
		
	}

}
