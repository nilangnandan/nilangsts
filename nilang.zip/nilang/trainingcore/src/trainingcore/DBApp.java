package trainingcore;

public class DBApp implements DBoperations, DBoperations2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBoperations db = new DBApp();
		
	}

	@Override
	public void updateEmpl() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addEmployee() {
		// TODO Auto-generated method stub
		
	}

}
