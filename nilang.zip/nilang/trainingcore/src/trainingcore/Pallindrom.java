package trainingcore;

public class Pallindrom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str = new StringBuffer(args[0]);
		/*
		for(int i=0; i< str.length();i++) {
			if(str.charAt(i) != str.charAt(str.length()-i-1)) 
				System.out.println("Not Pallindrome");break;
		}
		System.out.println("Pallindrome");
		*/
		StringBuffer str2= new StringBuffer(args[0]); 
		if(str2==str.reverse())
			System.out.println("Pallindrome");
		else System.out.println("Not Pallindrome" );
	}

}
