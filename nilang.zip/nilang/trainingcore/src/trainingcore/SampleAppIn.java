package trainingcore;

public class SampleAppIn extends Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleAppIn sam = new SampleAppIn();
		sam.display();
		
	}

	@Override
	void display() {
		// TODO Auto-generated method stub
			System.out.println("abstract method");
		}

	
}
