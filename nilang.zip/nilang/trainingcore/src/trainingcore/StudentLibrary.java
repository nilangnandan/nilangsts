package trainingcore;

public class StudentLibrary extends Student { 
	
	private int bookDue;	
	
	public StudentLibrary(int regno, String studentName, String group, int bookDue) {
	super(regno, studentName, group);
	this.bookDue = bookDue;
}
	//This is inheritance StudentLibrary is Subclass Student is Superclass
	
	
	public void info() {
		System.out.println(regno +" "+studentName +" "+group+" "+bookDue);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentLibrary std = new StudentLibrary(123, "buecf","cdvu",46);
		std.display();
		std.info();
	}

}
