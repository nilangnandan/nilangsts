package trainingcore;

public class Student {
	protected int regno;
	protected String studentName;
	protected String group;
	//
    public Student() {
		// TODO Auto-generated constructor stub
	}
	public Student(int regno, String studentName, String group) {
		this.regno = regno;
		this.studentName = studentName;
		this.group = group;
	}

	public void display() {
		 System.out.println(regno +" "+studentName+" "+group);
		 System.out.println("Hello from the other class");
	}
	/*
	public Student() {
		regno= 123;
		studentName = "Virtusa";
		group = "xlab ";
	}
	*/
}
