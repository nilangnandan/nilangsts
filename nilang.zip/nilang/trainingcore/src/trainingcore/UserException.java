package trainingcore;

import java.util.Scanner;

class EmployeeNotFoundException extends Exception{

	public EmployeeNotFoundException() {
		super("employee not found..  ");
		// TODO Auto-generated constructor stub
	}
	
}
public class UserException {
	
	public static void main(String[] args) {
		int code =12345;
		Scanner sc = new Scanner(System.in);
		int c= sc.nextInt()	;
		try {
			if(c!= code) {
				throw new EmployeeNotFoundException(); //Throwable exception
			}
			System.out.println("Welcome to Virtusa");
		}
		catch(EmployeeNotFoundException e) {
			//e.printStackTrace()	;
			System.out.println(e.getMessage());
		}
	}

}
