package trainingcore;

public class TwoDimensionArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[][] = new int[3][4];
		int y[][]= new int [3][4];
		int z[][]= new int [3][4];
		for(int i=0; i<3; i++) {
			
			for(int j=0; j<4; j++) {
				x[i][j] = i+j;
				y[i][j] = i+j+4;
				
			}
				
		}
		for(int i=0; i<3; i++) {
			System.out.println();
			for(int j=0; j<4; j++) {
				z[i][j] = x[i][j]+y[i][j];
				System.out.print(z[i][j] + " ");
			}
				
		}
	}

}
