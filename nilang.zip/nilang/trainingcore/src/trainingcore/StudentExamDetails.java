package trainingcore;

public class StudentExamDetails extends Student {
	
	private int sub1;
	private int sub2;
	private int sub3;
			
	protected int total;
	protected String res;
	protected double avg;
	
	public StudentExamDetails() {
		super();
		
	}
	public StudentExamDetails(int regno, String studentName, String group) {
		super(regno, studentName, group);
		
		// TODO Auto-generated constructor stub
	}
	
	public StudentExamDetails(int sub1, int sub2, int sub3) {
		this.sub1 = sub1;
		this.sub2 = sub2;
		this.sub3 = sub3;
	}
	public void result(int sub1, int sub2, int sub3) {
		int pass=40;
		
		
		int total;
		if(sub1< pass || sub2 < pass || sub3 < pass) {
			System.out.print("Status :");
			System.out.println("Fail");
		}
		else {
			total= sub1+ sub2+ sub3;
			avg= total/3;
			System.out.print("Average = ");
			System.out.println(avg);
			double percent = avg ;
			System.out.print("Percentage : ");
			System.out.println(percent+" %");
			
			if(percent < 40 ) {
				res= "fail";
				System.out.print("Status :");
				System.out.println("Fail");
			}
			else {
				res= "Pass";
				System.out.print("Status :");
				System.out.println("Pass");
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentExamDetails std = new StudentExamDetails(1234,"Nilang","xlab");
		std.display();
		std.result(85, 65, 98);
		
	}

}
