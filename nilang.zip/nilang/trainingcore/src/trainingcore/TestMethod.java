package trainingcore;

public class TestMethod {
	private int x;
	private int y;
	void add(int x, int y) {
		 this.x = x; // "this" define class variable
		 this.y = y;
		 System.out.println(x+y);
	}
	
	void add( double x, double y) {
		System.out.println(x+y);
	}
	void add( String x, String y) {
		System.out.println(x+y);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestMethod test = new TestMethod();
		test.add(10, 35);
	}

}
