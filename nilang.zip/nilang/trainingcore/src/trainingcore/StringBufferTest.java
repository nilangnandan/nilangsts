package trainingcore;

public class StringBufferTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=  new StringBuffer();
		sb.append("Hyderabad");
		System.out.println(sb);
		sb.append("Virtusa");
		System.out.println(sb.reverse());
		System.out.println(sb);
		System.out.println(sb.delete(5,8));
		StringBuffer sb1= new StringBuffer("CJdj");
		System.out.println(sb1);
		String str ="Hyd";
		StringBuffer sb2 = new StringBuffer(str);
		String str1 = sb.toString();
		
		
	}

}
