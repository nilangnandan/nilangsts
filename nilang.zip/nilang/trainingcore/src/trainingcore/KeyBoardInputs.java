package trainingcore;

import java.util.Scanner;

public class KeyBoardInputs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the details code, Name, Salary");	
		int code = sc.nextInt()	;
		String name = sc.next()	;
		double sal = sc.nextDouble();
		System.out.println(code +" "+name+" "+sal);
	}

}
