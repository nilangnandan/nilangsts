package trainingcore;

public class CommandLine {

	public static void main(String[] args) {
		String name = "Nilang";
		String city = args[0];
		String mobile=  args[1];
		int code = Integer.parseInt(args[2]);
		double sal = Double.parseDouble(args[3]);
		System.out.println(name+" "+args[0]+" "+args[1]+ " "+ args[2]+ " " +args[3]);
	}

}
