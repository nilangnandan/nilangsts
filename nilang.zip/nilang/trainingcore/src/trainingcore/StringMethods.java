package trainingcore;

public class StringMethods {

	public static void main(String[] args) {
		String str= "Hyderabad"; // only store value in stringpool
		String str1 = new String("India"); // using class and save value in heap 
		System.out.println("length is  "+ str.length());
		System.out.println("charAt "+ str.charAt(4));
		System.out.println("Substring using start index only "+ str.substring(2));
		System.out.println("Substring using stsrt and end "+ str.substring(2, 4));
		System.out.println("Concat " +str.concat("sucks"));
		System.out.println("Replace "+ str.replace('r', 'R'));
		System.out.println(str);
	}

}
