package trainingcore;

public class TestException {

	public static void main(String[] args) {
		int x= 7;
		int y= 4;
		int a[]	= {4,56,6,8};
		try {
			int r= x/y;
			System.out.println("result "+r);
			System.out.println("elemnt "+a[3]);
		}
		catch(ArithmeticException e) {
			System.out.println("Division cannot be done");
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println("value not available");
		}
		System.out.println("Sucess");
	}

}
