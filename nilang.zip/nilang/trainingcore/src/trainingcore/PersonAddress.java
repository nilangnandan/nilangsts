package trainingcore;

public class PersonAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Nilang Nandan");
		System.out.println("Gowlidoddy");
		System.out.println("Hyderabad");
		
	}

}
