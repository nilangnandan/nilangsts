package trainingcore;

public class WordCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "a this is A sentance with black spaces";
		int count =0;
		for(int i=0; i< str.length(); i++) {
			if((i!=0 && str.charAt(i)!= ' ' && str.charAt(i-1)== ' ' )||( str.charAt(i)!= ' '&& i==0))
				count++;
		}
		System.out.println(count);
		int vowel=0;
		str=  str.toLowerCase();
		for(int i=0; i< str.length(); i++) {
			if(str.charAt(i)=='a' || str.charAt(i)== 'e' || str.charAt(i)== 'i'|| str.charAt(i)== 'o' || str.charAt(i)== 'u')
				vowel++;
		}
		System.out.println(vowel);
	}

}
