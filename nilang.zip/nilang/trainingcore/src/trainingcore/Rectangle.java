package trainingcore;

public class Rectangle extends Shape{

	public Rectangle(double length, double breadth) {
		super(length, breadth);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle area = new Rectangle(48,52);
		area.findArea();
	}

	@Override
	void findArea() {
		// TODO Auto-generated method stub
		System.out.println("Area is "+ length*breadth);
	}


}
