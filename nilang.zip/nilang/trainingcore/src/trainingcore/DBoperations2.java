package trainingcore;

public interface DBoperations2 {
	void updateEmpl();
	
}
