package trainingcore;

public class Aeroplane implements Vehicle{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aeroplane airbus = new Aeroplane();
		airbus.wheels();
		airbus.engine();
	}

	@Override
	public void engine() {
		// TODO Auto-generated method stub
		System.out.println("It has 2 engine");
	}

	@Override
	public void wheels() {
		// TODO Auto-generated method stub
		System.out.println("It has 18 wheels");
	}

}
