package trainingcore;

public interface Vehicle {
	void engine();
	void wheels();
	
}
