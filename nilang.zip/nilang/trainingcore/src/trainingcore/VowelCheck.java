package trainingcore;

public class VowelCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char alphabet= 'e';
		switch(alphabet) {
			case 'a': 
				
			case 'e':
				
			case 'i':
				
			case 'o':	
				
			case 'u':	
				System.out.println("Vowel");break;
			default:
				System.out.println("Consonant");break;
		}
	}

}
