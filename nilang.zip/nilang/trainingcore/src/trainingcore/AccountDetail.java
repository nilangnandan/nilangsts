package trainingcore;

public class AccountDetail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setName("virtusa");
		employee.setCode(123);
		employee.setSalary(1648913489);
		System.out.println("Employee");
		System.out.println(" " + employee.getName()+" " +employee.getCode()+" "+ employee.getSalary());
	}

}
