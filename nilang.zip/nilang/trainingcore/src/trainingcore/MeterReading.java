package trainingcore;

public class MeterReading {

	public static void main(String[] args) {
		/*String serviceno;
		double previous;
		double present;
		double totalunits;
		*/
		if (Integer.parseInt(args[2])< Integer.parseInt(args[1])) {
			System.out.println("Invalid Entry");
		}
		else {
			int uses = Integer.parseInt(args[2])- Integer.parseInt(args[1]);
			double amount=0;
			
			if(uses > 200) {
				float price[] = {5,5,7.20f,8.50f,9,9,9,9,9.50f};
				int i=0;
				
					while(uses>0 && i<price.length);{
					amount= Math.min( 100, uses)*price[i] + amount;
					uses=uses- 100;
					i++;
					}
					
				if(i==price.length && uses>0 )
					amount += (uses*9.5);
				System.out.println(args[0]+" has amount "+ amount);
			}
			else if(uses>100) {
				amount= ((uses-100)* 3.3 )+ amount;
				uses = uses-100;
				if(uses >0)
					amount= (uses*4.3)+amount;
				System.out.println(args[0]+" has amount "+ amount);
			}
			else {
				if(uses >= 50) {
					uses= uses-50;
					amount+= (50*1.45)+ uses*2.6 ;
					System.out.println(args[0]+" has amount "+ amount);
				}
				else {
					amount += uses*1.45;
					System.out.println(args[0]+" has amount "+ amount);
				}
			}
			
		}

	}

}
