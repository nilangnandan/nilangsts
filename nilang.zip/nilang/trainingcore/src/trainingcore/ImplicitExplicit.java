package trainingcore;

public class ImplicitExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte x= 100;
		int y= x; // implicit casting
		int z= 324165;
		short s= (short) z; //explicit casting
		System.out.println(s);
		
	}

}
