package trainingcore;

public interface DBoperations {
	int x=70;
	void addEmployee();
	
}
