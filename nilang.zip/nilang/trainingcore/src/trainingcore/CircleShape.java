package trainingcore;

public class CircleShape extends Shape{

	public CircleShape(double radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircleShape area=  new CircleShape(14);
		area.findArea();
	}

	@Override
	void findArea() {
		// TODO Auto-generated method stub
		System.out.println("Area is "+ 3.14*radius*radius);
	}

}
