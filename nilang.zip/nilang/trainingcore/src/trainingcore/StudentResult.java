package trainingcore;

public class StudentResult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int regno=140107034; 
		int sub1=82; 
		int sub2=69; 
		int sub3=85;
		int pass=40;
		int avg;
		
		System.out.println(regno);
		
		int cat;
		if(sub1< pass || sub2 < pass || sub3 < pass) {
			System.out.print("Status :");
			System.out.println("Fail");
		}
		else {
			
			avg= sub1+ sub2+ sub3;
			System.out.print("Average = ");
			System.out.println(avg);
			int percent = avg * 100/300;
			System.out.print("Percentage : ");
			System.out.println(percent);
			
			if(percent < 40 ) {
				cat= 30;
				System.out.print("Status :");
				System.out.println("Fail");
			}
			else if(percent < 60) {
				cat=50;
			}
			else {
				cat=60;
			}
		}
		
	}
}
