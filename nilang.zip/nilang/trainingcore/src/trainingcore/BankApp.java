package trainingcore;

public class BankApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account = new Account();// implicit constructor
		account.setBalance(Integer.parseInt(args[2]));
		account.setCode(Integer.parseInt(args[0]));
		account.setName(args[1]);
		System.out.println(account.getCode());
		System.out.println(account.getName()+ " " + account.getBalance());
		Account acn= new Account(); 
		System.out.println(acn.getName()+ " "+ acn.getBalance());
	}

}
