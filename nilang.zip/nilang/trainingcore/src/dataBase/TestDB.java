package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class TestDB {

	public static void main(String[] args) throws SQLException {
		Driver driver = new Driver();
		DriverManager.registerDriver(driver);
		String url = "jdbc:mysql://localhost:3306/virtusa";
		String user = "root";
		String pass= "system";
		Connection conn = DriverManager.getConnection(url, user, pass);
		System.out.println("connected");
		//create a table
		Statement st = (Statement) conn.createStatement();
		String sql = "insert into emp values (101,'virtusa', 5000)";
		st.executeUpdate(sql);
		System.out.println("inserted");
		conn.close();
	}

}
