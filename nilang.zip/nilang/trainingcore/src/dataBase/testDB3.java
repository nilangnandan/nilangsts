package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;

public class testDB3 {

	public static void main(String[] args) throws SQLException {
		Driver driver = new Driver();
		DriverManager.registerDriver(driver);
		String url = "jdbc:mysql://localhost:3306/virtusa";
		String user = "root";
		String pass= "system";
		Connection conn = DriverManager.getConnection(url, user, pass);
		System.out.println("connected");
		String sql = "update emp set salary = ? where code =?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setDouble(1, 2500);
		pst.setInt(2, 101);
		pst.executeUpdate();
		conn.close();
	}

}
