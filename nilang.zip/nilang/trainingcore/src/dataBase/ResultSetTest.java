package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class ResultSetTest {

	public static void main(String[] args) throws SQLException {
		Driver driver = new Driver();
		DriverManager.registerDriver(driver);
		String url = "jdbc:mysql://localhost:3306/virtusa";
		String user = "root";
		String pass= "system";
		Connection conn = DriverManager.getConnection(url, user, pass);
		System.out.println("connected");
		String sql = "select * from emp";
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(sql);
		ResultSetMetaData metadata = rs.getMetaData();
		for(int i=1; i<= metadata.getColumnCount();i++)
			System.out.print(metadata.getColumnName(i)+" ");
		System.out.println("\n-------------");
		while(rs.next())
			System.out.println(rs.getInt(1)+" "+rs.getString("name")+" "+rs.getDouble(3));
		conn.close();
	}

}
