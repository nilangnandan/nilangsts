package threads;

public class SampleThread {
	public static void main(String[] args) {
		Reservations res = new Reservations();
		/*System.out.println("Enter Number of seats initialy available");
		Scanner sc = new Scanner(System.in);
		int avail = sc.nextInt();
		res.setAvailable(avail);*/
		Thread t1 = new Thread(res);
		Thread t2 = new Thread(res);
		Thread t3 = new Thread(res);
		t1.setName("Ram");
		t2.setName("Dudi");
		t3.setName("Harsh");
		t1.start();
		t2.start();
		t3.start();
	}
}
