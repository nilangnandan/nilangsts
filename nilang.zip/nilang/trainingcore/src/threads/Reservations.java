package threads;

import java.util.Scanner;

public class Reservations implements Runnable{
	int available=10;
	
	public int getAvailable() {
		return available;
	}

	public void setAvailable(int available) {
		this.available = available;
	}

	@Override
	public synchronized void run() {
		System.out.println("Number of seats available "+ available);
		if(available>0) {
			System.out.println("Hi "+ Thread.currentThread().getName());
			System.out.println("Enter Number of seats want to book");
			Scanner sc = new Scanner(System.in);
			int book = sc.nextInt();
			if(book> available) {
				System.out.println("Hi "+ Thread.currentThread().getName()+" seat you want to book is more than available seat");
				System.out.println("Do you want to book available seats? Enter y for YES and n for NO");
				String response = sc.next();
				if(response.equals("y")) {
					System.out.println("Booking sucessfully");
					available= 0;
				}
				else 
					System.out.println("Booking failed");	
			}
			else {
				System.out.println("Booking sucessfully");
				available= available - book;
			}
			sc.close();
		}
		else {
			System.out.println("Sorry "+ Thread.currentThread().getName()+" no seat is available.");
		}
		
	}

}
