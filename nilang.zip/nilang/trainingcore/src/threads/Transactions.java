package threads;

public class Transactions {
	int balance = 5000;
	synchronized void withdraw(int amount) {
		System.out.println("Available balance = "+this.balance);
		System.out.println("Request Amount ... "+amount);
		System.out.println("Trying to withdraw...");
		if(this.balance < amount) {
			System.out.println("Less balance; waiting for deposit ..");
			try {
				wait();
				Thread.sleep(8000);
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.balance -= amount;
		System.out.println("Withdraw completed.. balance is : " + this.balance);
	}
	
	synchronized void deposit(int amount) {
		System.out.println("Trying to deposit... ");
		this.balance+=amount;
		try {
			Thread.sleep(2000);
			
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Deposit complete ... Available Balance : " + this.balance);
		notify();
	}
}
