package bankApp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ImprovedAccountOperations {
	private ArrayList<Account> acc = new ArrayList<>();
	public ImprovedAccountOperations() {
		Account newacc1 = new Account(1230, "Rituraj", 7000);
		Account newacc2 = new Account(1231, "Gorakh", 8000);
		Account newacc3 = new Account(1232, "Kushal", 9000);
		Account newacc4 = new Account(1233, "Ram", 10000);
		acc.add(newacc1);
		acc.add(newacc4);
		acc.add(newacc3);
		acc.add(newacc2);
	}
	
	int newnum= 1234;
	public void deposit(int accno, double amount) {
		byte count =0;
		try {
			for(Account emp : acc) {
				if(emp.getAccountNumber()== accno) {
					emp.setBalance(emp.getBalance()+amount);
					count=1;
					System.out.println("Amount added" );
					System.out.println("Transaction sucessful. " );
					break;
				}
			}
			if(count==0) {
				throw new AccountNotFoundException();
			}
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}	
	}
	//Withdraw method
	public void withdraw(int accno, double amount) {
		byte count =0;
		try {
			for(Account emp : acc) {
				if(emp.getAccountNumber()== accno) {
					count=1;
					try {
						if(emp.getBalance()< amount)
							throw new InsufficientFundException();
						emp.setBalance(emp.getBalance()-amount);
						System.out.println("Amount withdrawn" );
						System.out.println("Transaction sucessful. " );
						break;
					}
					catch(InsufficientFundException e) {
						System.out.println(e.getMessage());
					}
				}
			}
			if(count==0) 
				throw new AccountNotFoundException();
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Check Balance
	public void balanceCheck(int accno) {
		int count=0;
		try {
			for(Account emp : acc) {
				if(emp.getAccountNumber()== accno) {
					count=1;
					System.out.println("Account Number : "+emp.getAccountNumber()+" has balance "+emp.getBalance());
					break;
				}
			}
			if(count==0)
				throw new AccountNotFoundException();
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Create Account
	public int createAccount() {
		System.out.println("Enter the name of Customer : ");
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		System.out.println("Enter amount to be added : ");
		int amount = sc.nextInt();
		Account newacc = new Account(newnum, name, amount);
		newnum++;
		acc.add(newacc);
		sc.close();
		return newacc.getAccountNumber();
		
	}
	
	//list Account sort by Name
	public void listDetails(){
		Collections.sort(acc, new SortByCustomerName());
		for(Account emp : acc)
			System.out.println(emp.getAccountNumber()+" "+emp.getCustomerName()+" "+emp.getBalance());
	}
}
