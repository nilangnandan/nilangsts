package bankApp;

import java.util.Comparator;

public class SortByCustomerName implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		int diff = o1.getCustomerName().compareTo(o2.getCustomerName());
		return diff;
	}

}
