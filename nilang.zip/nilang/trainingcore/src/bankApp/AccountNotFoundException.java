package bankApp;

public class AccountNotFoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotFoundException() {
		super("Account not found..  ");
		// TODO Auto-generated constructor stub
	}
}
