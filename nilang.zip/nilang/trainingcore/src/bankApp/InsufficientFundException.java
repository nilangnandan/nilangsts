package bankApp;

public class InsufficientFundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFundException() {
		super("Insufficient Fund");
		// TODO Auto-generated constructor stub
	}
}
