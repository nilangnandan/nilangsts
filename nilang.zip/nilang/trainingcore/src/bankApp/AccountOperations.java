package bankApp;

public class AccountOperations {
	private Account accounts[]= new Account[25];
	public AccountOperations() {
		accounts[0] = new Account(1234, "Rituraj", 4000);
		accounts[1] = new Account(1235, "Kushal", 5000);
		accounts[2] = new Account(1236, "Nilang", 6000);
		accounts[3] = new Account(1237, "Sarika", 7000);
		accounts[4] = new Account(1238, "Gorakh", 8000);
	}
	public void deposit(int accno, double amount) {
		byte count =0;
		try {
			for(int i=0; i< accounts.length; i++) {
				if(accounts[i]== null)
					throw new AccountNotFoundException();
				if(accounts[i].getAccountNumber()==accno) {
					accounts[i].setBalance(amount+accounts[i].getBalance());
					count=1;
					System.out.println("Amount added" );
					System.out.println("Transiction sucessful. " );
					break;
				}
			}
			if(count==0) {
				throw new AccountNotFoundException();
			}
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
			
	}
	
	public void withdraw(int accno, double amount) {
		byte count =0;
		try {
			for(int i=0; i< accounts.length; i++) {
				if(accounts[i]== null)
					throw new AccountNotFoundException();
				if(accounts[i].getAccountNumber()==accno) {
					count=1;
					try {
						if(accounts[i].getBalance()< amount) 
							throw new InsufficientFundException();
						
						
						accounts[i].setBalance(accounts[i].getBalance()- amount);
							
						System.out.println("Amount withdrawn" );
						System.out.println("Transiction sucessful. " );
						break;
					}
					catch(InsufficientFundException e) {
						System.out.println(e.getMessage());
					}
				}
			}
			if(count==0) 
				throw new AccountNotFoundException();
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public void balanceCheck(int accno) {
		byte count =0;
		try {
			for(int i=0; i< accounts.length; i++) {
				if(accounts[i]== null)
					throw new AccountNotFoundException();
				if(accounts[i].getAccountNumber()==accno) {
					System.out.println("Balance is "+ accounts[i].getBalance() );
					count=1;
					break;
				}
			}
			if(count==0)
				throw new AccountNotFoundException();
		}
		catch(AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}
	public int createAccount(String name, double amount) {
		for(int i=0; i< accounts.length; i++) {
			if(accounts[i]==null ) {
				/*
				 * accounts[i].setAccountNumber(accounts[i-1].getAccountNumber()+1);
				 * accounts[i].setCustomerName(name);
				 * accounts[i].setBalance(amount);
				 
				accounts[i].setCustemerName(name);
				*/
				accounts[i] = new Account(accounts[i-1].getAccountNumber()+1, name, amount);
				return accounts[i].getAccountNumber();
				
			}
		}
		System.out.println("Maximum limit reached, Increase the limit of account");
		return 0;
	}
	public void listDetails() {
		for(int i=0; i< accounts.length; i++) {
			if(accounts[i]!=null ) {
				System.out.println(accounts[i].getAccountNumber()+" "+accounts[i].getCustomerName()+" "+accounts[i].getBalance());
			}
			else break;
		}
	}
	
}
