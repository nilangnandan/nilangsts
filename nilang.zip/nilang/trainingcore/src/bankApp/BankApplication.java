package bankApp;

import java.util.Scanner;

public class BankApplication{

	
	public static void message() {
		System.out.println("Enter the appropriate alphabet");
		System.out.println("d - Deposit ");
		System.out.println("w - Withdraw ");
		System.out.println("b - Balance ");
		System.out.println("c - Create Account ");
		System.out.println("l - List Account Details");
		System.out.println("x - Exit ");
		
	}
	public static void main(String[] args) {
		ImprovedAccountOperations opers = new ImprovedAccountOperations();
		
		message();
		Scanner input = new Scanner(System.in);
		String in = input.next();
		//System.out.println(in);
		while(!in.equals("x")) {
			if(in.equals("d")) {
				System.out.println("Please enter the Account Number & amount to be deposit");
				
				int accNo= input.nextInt()	;
				double amount = input.nextDouble();
				opers.deposit(accNo, amount);
				message();
				in = input.next();
			}
			else if(in.equals("w")) {
				System.out.println("Please enter the Account Number & amount to be withdraw");
				
				int accNo= input.nextInt()	;
				double amount = input.nextDouble();
				opers.withdraw(accNo, amount);
				message();
				in = input.next();
			}
			else if(in.equals("b")) {
				System.out.println("Please enter the Account Number ");
				int accNo= input.nextInt()	;
				opers.balanceCheck(accNo);
				message();
				in = input.next();
			}
			else if(in.equals("l")) {
				System.out.println("List of all account details. ");
				opers.listDetails();
				message();
				in = input.next();
			}
			else if(in.equals("c")) {
				int var = opers.createAccount();
				System.out.println("Congratulation you have sucessfully created an account. Your account number is "+var);
				message();
				in = input.next();
			}
			
			else {
				System.out.println("Please enter a valid response");
							
				message();
				in= input.next();
			}
		}
		input.close();
		System.out.println("Thank you Visit again.");
	}

}
