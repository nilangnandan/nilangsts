package inputoutputtest;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WritingObject {

	public static void main(String[] args) {
		try {
			FileOutputStream fos= new FileOutputStream("C:\\Users\\nilangn\\Downloads\\customer.dat");
			Customer cust1 = new Customer(123, "abcd", 5000	);
			Customer cust2=  new Customer(456, "dhfy", 6785);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(cust1);
			oos.writeObject(cust2);
			oos.close();
			fos.close();
			System.out.println("created");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
