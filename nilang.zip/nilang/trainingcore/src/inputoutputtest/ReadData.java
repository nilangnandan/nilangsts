package inputoutputtest;

import java.io.FileInputStream;
import java.io.IOException;

public class ReadData {
	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream("C:\\Users\\nilangn\\Downloads\\sample.txt");
			int x;
			while((x=fis.read())!= -1)
				System.out.println((char)x);
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
