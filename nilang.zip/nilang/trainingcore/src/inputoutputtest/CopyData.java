package inputoutputtest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyData {

	public static void main(String[] args) {
		//file.mkdir();
		try {
			FileInputStream fis = new FileInputStream("C:\\Users\\nilangn\\Downloads\\sample.txt");
			FileOutputStream fos = new FileOutputStream("C:\\Users\\nilangn\\Downloads\\newFile.txt");
			int x;
			while((x=fis.read())!= -1)
				fos.write(x);
			fis.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
