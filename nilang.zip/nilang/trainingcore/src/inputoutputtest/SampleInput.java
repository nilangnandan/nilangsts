package inputoutputtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SampleInput {

	public static void main(String[] args) {
		InputStreamReader isr= new InputStreamReader(System.in);
    	BufferedReader br = new BufferedReader(isr);
        try {
			int a = Integer.parseInt(br.readLine());
			int b = Integer.parseInt(br.readLine());
			//a=5;
			//b=0;
			int c=a/b;
			System.out.println("The quotient of "+a+"/"+b+"="+c);
		} catch (NumberFormatException | IOException |ArithmeticException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+" caught");
		}
        finally {
        	System.out.println("Inside finally block");
        }
	}

}
