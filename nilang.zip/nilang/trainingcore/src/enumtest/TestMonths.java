package enumtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestMonths {

	public static void main(String[] args) {
		try {
			System.out.println("Enter month : ");
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			Months month;
			
			month = Months.valueOf(br.readLine());
		
			switch(month) {
			case JAN:
			case FEB:
			case MAR:
			case APR:
			case MAY:
			case JUNE:
			case JULY:
			case AUG:
			case SEP:
			case OCT:
			case NOV:
			case DEC:
				System.out.println(month.getClass());break;
				default:
					System.out.println("Invalid Entry");
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
