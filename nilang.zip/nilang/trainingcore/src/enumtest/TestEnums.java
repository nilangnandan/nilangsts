package enumtest;

public class TestEnums {

	public static void main(String[] args) {
		CarModels model = CarModels.BREEZA;
		if(model == CarModels.SWIFT)
			System.out.println("available");
		else 
			System.out.println("not available");
		
		switch(model) {
		case BREEZA: 
		case SWIFT:
		case BALENO:
		case DZIRE:
			System.out.println("available");break;
			default:
				System.out.println("not available");
			
		}
	}

}
