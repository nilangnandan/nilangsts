package enumtest;

public enum CarModels {
	BREEZA, SWIFT, DZIRE, BALENO,
}
