package com.virtusa.employee.dao;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Driver;
import com.virtusa.employee.beans.Employee;
import com.virtusa.employee.utils.DateParsing;
import com.virtusa.employee.utils.EmplDBQueries;

public class EmployeeDao {
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	
	public void openConnection() {
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			String url = "jdbc:mysql://localhost:3306/virtusa";
			String user = "root";
			String pass= "system";
			conn = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int addEmployee(Employee emp) {
		openConnection();
		int rows=0;
		try {
			pst = conn.prepareStatement(EmplDBQueries.addempl);
			pst.setInt(1, emp.getEmpcode());
			pst.setString(2, emp.getEmpname());
			pst.setString(3, emp.getJob());
			pst.setDouble(4, emp.getSalary());
			pst.setDate(5, DateParsing.convertDate(emp.getDoj()));
			rows = pst.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		closeConnection();
		return rows;
	}
	
	public List<Employee> getAllEmpls(){
		openConnection();
		List<Employee> empList = new ArrayList<Employee>();
		try {
			pst=conn.prepareStatement(EmplDBQueries.getAllEmpls);
			rs=pst.executeQuery();
			while(rs.next()) {
				Employee emp = new Employee();
				emp.setEmpcode(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setJob(rs.getString(3));
				emp.setSalary(rs.getDouble(4));
				emp.setDoj(rs.getDate(5).toString());
				empList.add(emp);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		closeConnection();
		return empList;
	}
	
	public Employee getEmpl(int code) {
		openConnection();
		Employee emp = null;
		try {
			pst=conn.prepareStatement(EmplDBQueries.getEmpls);
			pst.setInt(1, code);
			rs=pst.executeQuery();
			if(rs.next()) {
				emp= new Employee();
				emp.setEmpcode(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setJob(rs.getString(3));
				emp.setSalary(rs.getDouble(4));
				emp.setDoj(rs.getDate(5).toString());
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return emp;
	}
	
	public int updateEmpl(Employee emp) {
		openConnection();
		int rows =0;
		try {
			
			    pst=conn.prepareStatement(EmplDBQueries.updateEmpls);
				pst.setInt(5, emp.getEmpcode());
				pst.setString(1, emp.getEmpname());
				pst.setString(2, emp.getJob());
				pst.setDouble(3, emp.getSalary());
				pst.setDate(4, DateParsing.convertDate(emp.getDoj()));
				rows=pst.executeUpdate();
				
			}
			
		
		catch(SQLException e){
			e.printStackTrace();
		}
		closeConnection();
		
		return rows;
	}
	public int deleteEmpl(int code) {
		openConnection();
		int rows=0;
		try {
			pst=conn.prepareStatement(EmplDBQueries.deleteEmpls);
			pst.setInt(1, code);
			rows =pst.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		closeConnection();
		return rows;
	}
}
