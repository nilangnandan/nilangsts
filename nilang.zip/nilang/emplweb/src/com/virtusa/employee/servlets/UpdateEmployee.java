package com.virtusa.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.employee.beans.Employee;
import com.virtusa.employee.dao.EmployeeDao;

/**
 * Servlet implementation class UpdateEmployee
 */
@WebServlet("/UpdateEmployee")
public class UpdateEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String data = request.getParameter("code");
		if(data!=null) {
			int code= Integer.parseInt(request.getParameter("code"));
			EmployeeDao dao= new EmployeeDao();
			Employee emp = dao.getEmpl(code);
			if(emp==null) {
				out.println("Entered code is not existing");
				out.println("redirecting to add employee");
				RequestDispatcher rd = request.getRequestDispatcher("AddEmployee.jsp");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd = request.getRequestDispatcher("UpdateEmployee.jsp");
				request.setAttribute("empls", emp);
				rd.forward(request, response);
			}
		}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("UpdateEmployeeWithCode.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int code= Integer.parseInt(request.getParameter("empcode"));
		String name= request.getParameter("empname");
		String job= request.getParameter("job");
		double sal= Double.parseDouble(request.getParameter("salary"));
		String doj= request.getParameter("doj");
		Employee emp = new Employee(code, name, job, sal, doj);
		EmployeeDao dao= new EmployeeDao();
		int rows= dao.updateEmpl(emp);
		if(rows>0)
			out.println("updated");
		else
			out.println("Not updated");
	}

}
