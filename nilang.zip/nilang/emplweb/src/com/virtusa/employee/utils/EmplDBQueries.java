package com.virtusa.employee.utils;

public class EmplDBQueries {
	public static String addempl = "insert into employee values(?,?,?,?,?)";
	public static String getAllEmpls = "select * from employee";
	public static String getEmpls = "select * from employee where empcode=?";
	public static String deleteEmpls = "delete from employee where empcode=?";
	public static String updateEmpls =" update employee set empname=?, job=?, salary =?,doj=? where empcode =?";
	//public static String getSalary = " select salary from employee where empcode =?";
}
