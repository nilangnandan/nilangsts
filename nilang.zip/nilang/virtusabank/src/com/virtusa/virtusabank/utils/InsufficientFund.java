package com.virtusa.virtusabank.utils;

public class InsufficientFund extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFund() {
		super("Insufficient Fund");
	}
	
}
