package com.virtusa.virtusabank.utils;

public class AccountNotFound extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotFound() {
		super("Invalid account");
	}
	
}
