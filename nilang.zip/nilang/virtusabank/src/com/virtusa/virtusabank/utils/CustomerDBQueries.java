package com.virtusa.virtusabank.utils;

public class CustomerDBQueries {
	public static String createAccount = "insert into account(customername, balance, dateopened) values(?,?,?)";
	public static String getAccount = "select  max(accountno) from account";
	public static String deposit = "update account set balance = balance+? where accountno =?";
	public static String withdraw = "update account set balance = balance-? where accountno =?";
	public static String getDetails= "select * from account where accountno =?";
	public static String insertDaybook = "insert into daybook values(?,?,?,?,?,?)";
	public static String getStatement = "select * from daybook where accountno=?";
}
