package com.virtusa.virtusabank.applications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.dao.AccountDao;

public class CheckBalance {

	public static void main(String[] args) {
		Account acc = new Account();
		System.out.println("Enter account number : ");
		try {
			InputStreamReader isr= new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			acc.setAccountno(Integer.parseInt(br.readLine()));
			AccountDao dao = new AccountDao();
			acc= dao.checkBalance(acc);
			if(acc.getCustomername() != null)
				System.out.println("Account number : "+acc.getAccountno()+", Customer name : "+ acc.getCustomername()+", balance : "+acc.getBalance());
		}
		catch (NumberFormatException | IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
