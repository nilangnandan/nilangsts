package com.virtusa.virtusabank.applications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.beans.Daybook;
import com.virtusa.virtusabank.dao.DaybookDao;

public class DaybookStatement {

	public static void main(String[] args) {
		List<Daybook> statementList = new ArrayList<Daybook>();
		Account acc= new Account();
		DaybookDao dao = new DaybookDao();
		System.out.println("Enter account number : ");
		try {
			InputStreamReader isr= new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			acc.setAccountno(Integer.parseInt(br.readLine()));
			statementList = dao.getStatement(acc);
			for(Daybook e : statementList)
				System.out.println(e.getAccountno()+ " "+e.getTrandate()+" "+e.getTrantype()+" "+e.getDescription()+" "+e.getAmount()+" "+e.getBalance());
		}
		catch (NumberFormatException | IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
