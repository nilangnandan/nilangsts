package com.virtusa.virtusabank.applications;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.dao.AccountDao;

public class CreateAccount {

	public static void main(String[] args) {
		
		try {
			InputStreamReader isr= new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			System.out.println("Enter Customer name : ");
			String name = br.readLine();
			System.out.println("Enter opening amount : ");
			double balance = Double.parseDouble(br.readLine());
			Date dt = new Date();
			java.sql.Date dt1 = new java.sql.Date(dt.getTime());
			Account acc = new Account(name, balance,  dt1);
			AccountDao dao = new AccountDao();
			int rows = dao.createAccount(acc);
			if(rows>0)
				System.out.println("Account has been sucessfully created and your account number is : "+ rows+" Customer name : "+name);
			else
				System.out.println("Sorry we are having some technical issue. Try after some time.");
		} catch (NumberFormatException | IOException e) {
			System.out.println(e.getMessage());
		}
		
		//
	}

}
