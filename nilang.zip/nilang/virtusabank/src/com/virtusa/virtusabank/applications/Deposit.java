package com.virtusa.virtusabank.applications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.dao.AccountDao;

public class Deposit {

	public static void main(String[] args) {
		Account acc = new Account();
		System.out.println("Enter account number : ");
		try {
			InputStreamReader isr= new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			acc.setAccountno(Integer.parseInt(br.readLine()));
			System.out.println("Enter amount: ");
			acc.setBalance(Double.parseDouble(br.readLine()));
			Date dt = new Date();
			java.sql.Date dt1 = new java.sql.Date(dt.getTime());
			acc.setDateopened(dt1);
			AccountDao dao = new AccountDao();
			int rows = dao.deposit(acc);
			if(rows >0)
				System.out.println("Sucessfully deposit");
			else 
				System.out.println("unsucessful attempt");
		} catch (NumberFormatException | IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
