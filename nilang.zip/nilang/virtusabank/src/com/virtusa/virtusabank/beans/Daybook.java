package com.virtusa.virtusabank.beans;

import java.sql.Date;

public class Daybook {
	private int accountno;
	private java.sql.Date trandate;
	private String trantype;
	private String description;
	private double amount;
	private double balance;
	public Daybook() {
	}
	public Daybook(int accountno, Date trandate, String trantype, String description, double amount, double balance) {
		this.accountno = accountno;
		this.trandate = trandate;
		this.trantype = trantype;
		this.description = description;
		this.amount = amount;
		this.balance = balance;
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public Date getTrandate() {
		return trandate;
	}
	public void setTrandate(Date trandate) {
		this.trandate = trandate;
	}
	public String getTrantype() {
		return trantype;
	}
	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}
