package com.virtusa.virtusabank.beans;

import java.util.Date;

public class Account {
	private int accountno;
	private String customername;
	private double balance;
	private Date dateopened;
	public Account() {
		
	}
	public Account(int accountno, String customername, double balance, Date dateopened) {
		this.accountno = accountno;
		this.customername = customername;
		this.balance = balance;
		this.dateopened = dateopened;
	}
	public Account( String customername, double balance, Date dateopened) {
		this.customername = customername;
		this.balance = balance;
		this.dateopened = dateopened;
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Date getDateopened() {
		return dateopened;
	}
	public void setDateopened(Date dateopened) {
		this.dateopened = dateopened;
	}
	
}
