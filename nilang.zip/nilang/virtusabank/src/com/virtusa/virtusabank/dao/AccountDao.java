package com.virtusa.virtusabank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;
import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.utils.AccountNotFound;
import com.virtusa.virtusabank.utils.CustomerDBQueries;
import com.virtusa.virtusabank.utils.DateParsing;
import com.virtusa.virtusabank.utils.InsufficientFund;

public class AccountDao {
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	public void openConnection() {
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			String url = "jdbc:mysql://localhost:3306/virtusa";
			String user = "root";
			String pass= "system";
			conn = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public int createAccount(Account acc) {
		openConnection();
		int rows=0;
		try {
			pst = conn.prepareStatement(CustomerDBQueries.createAccount);
			pst.setString(1, acc.getCustomername());
			pst.setDouble(2, acc.getBalance());
			pst.setDate(3, DateParsing.convertDate(acc.getDateopened().toString()));
			pst.executeUpdate();
			pst = conn.prepareStatement(CustomerDBQueries.getAccount);
			rs= pst.executeQuery();
			if(rs.next()) {
				rows= rs.getInt(1);
				pst = conn.prepareStatement(CustomerDBQueries.insertDaybook);
				pst.setInt(1, rows);
				pst.setString(3, "deposit");
				pst.setDate(2, DateParsing.convertDate(acc.getDateopened().toString()));
				pst.setString(4, "Sucessfully created");
				pst.setDouble(5, acc.getBalance());
				pst.setDouble(6, acc.getBalance());
				pst.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		closeConnection();
		return rows;
	}
	public int deposit(Account acc) {
		openConnection();
		int rows =0;
		try {
			pst=conn.prepareStatement(CustomerDBQueries.deposit);
			pst.setInt(2, acc.getAccountno());
			pst.setDouble(1,acc.getBalance());
			rows=pst.executeUpdate();
			pst = conn.prepareStatement(CustomerDBQueries.getDetails);
			pst.setInt(1, acc.getAccountno());
			rs= pst.executeQuery();
			if(!rs.next())
				throw new AccountNotFound();
			pst = conn.prepareStatement(CustomerDBQueries.insertDaybook);
			pst.setInt(1, acc.getAccountno());
			pst.setString(3, "deposit");
			pst.setDate(2, DateParsing.convertDate(acc.getDateopened().toString()));
			pst.setString(4, "Sucessfully deposited");
			pst.setDouble(5,acc.getBalance() );
			pst.setDouble(6, rs.getDouble(3));
			pst.executeUpdate();	
		}
		catch(SQLException | AccountNotFound e){
			System.out.println(e.getMessage());
		}
		closeConnection();
		return rows;
	}
	
	public int withdraw(Account acc) {
		openConnection();
		int rows =0;
		try {
			pst=conn.prepareStatement(CustomerDBQueries.getDetails);
			pst.setInt(1,acc.getAccountno());
			rs = pst.executeQuery();
			if(!rs.next())
				throw new AccountNotFound();
			if(rs.getDouble(3)< acc.getBalance())
				throw new InsufficientFund();
			pst= conn.prepareStatement(CustomerDBQueries.withdraw);
			pst.setInt(2, acc.getAccountno());
			pst.setDouble(1, acc.getBalance());
			rows=pst.executeUpdate();
			pst = conn.prepareStatement(CustomerDBQueries.getDetails);
			pst.setInt(1, acc.getAccountno());
			rs= pst.executeQuery();
			if(!rs.next())
				throw new AccountNotFound();
			pst = conn.prepareStatement(CustomerDBQueries.insertDaybook);
			pst.setInt(1, acc.getAccountno());
			pst.setString(3, "withdraw");
			pst.setDate(2, DateParsing.convertDate(acc.getDateopened().toString()));
			pst.setString(4, "Sucessfully withdrawn");
			pst.setDouble(5,acc.getBalance() );
			pst.setDouble(6, rs.getDouble(3));
			pst.executeUpdate();	
		}
		catch(SQLException | InsufficientFund | AccountNotFound e){
			System.out.println(e.getMessage());
		}
		closeConnection();
		return rows;
		
	}
	public Account checkBalance(Account acc) {
		openConnection();
		try {
			pst = conn.prepareStatement(CustomerDBQueries.getDetails);
			pst.setInt(1,acc.getAccountno());
			rs = pst.executeQuery();
			if(!rs.next())
				throw new AccountNotFound();
			acc.setCustomername(rs.getString(2));
			acc.setBalance(rs.getDouble(3));
		}
		catch(SQLException | AccountNotFound e){
			System.out.println(e.getMessage());
		}
		closeConnection();
		return acc;
	}
}
