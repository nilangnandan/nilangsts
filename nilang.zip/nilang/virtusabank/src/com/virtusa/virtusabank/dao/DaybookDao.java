package com.virtusa.virtusabank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Driver;
import com.virtusa.virtusabank.beans.Account;
import com.virtusa.virtusabank.beans.Daybook;
import com.virtusa.virtusabank.utils.AccountNotFound;
import com.virtusa.virtusabank.utils.CustomerDBQueries;

public class DaybookDao {
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	public void openConnection() {
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			String url = "jdbc:mysql://localhost:3306/virtusa";
			String user = "root";
			String pass= "system";
			conn = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public List<Daybook> getStatement(Account acc) {
		openConnection();
		List<Daybook> statementList = new ArrayList<Daybook>();
		try {
			pst = conn.prepareStatement(CustomerDBQueries.getStatement);
			pst.setInt(1, acc.getAccountno());
			rs = pst.executeQuery();
			if(!rs.next())
				throw new AccountNotFound();
			else {
				do {
					Daybook list = new Daybook();
					list.setAccountno(acc.getAccountno());
					list.setTrantype(rs.getString(3));
					list.setTrandate(rs.getDate(2));
					list.setDescription(rs.getString(4));
					list.setAmount(rs.getDouble(5));
					list.setBalance(rs.getDouble(6));
					statementList.add(list);
				}while(rs.next());
			}
			
		} catch (SQLException | AccountNotFound e) {
			System.out.println(e.getMessage());
		}
		closeConnection();
		return statementList;
	}
}
